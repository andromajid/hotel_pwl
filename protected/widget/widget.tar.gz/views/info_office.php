<div class="wt">
    	<?php
        if(!empty($row))
        {
            echo $row['page_content'];
        }
        
        ?>
    </div>